quantity_of_hw = 12
hours_of_hw = 1.5
name_of_course = 'Python'
time_of_hw = hours_of_hw / quantity_of_hw
print ('Курс: ',name_of_course,', всего задач:',quantity_of_hw,', затрачено часов: ',hours_of_hw, ', среднее время выполнения ', time_of_hw, ' часа.')